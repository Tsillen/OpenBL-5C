PCB NAME: OpenBLC
DATE: 05-09-2014
TIME: 18:00
NAME: THIJS SILLEN
-----------------------------------
DRC CHECK: YES
MAJOR ERRORS: NO
-----------------------------------
Layer stackup:    Gerber extention:
Top layer         .GTO
bottom layer      .GBO
-----------------------------------
Board outline Layer: .GKO
-----------------------------------
Drill Files:
OpenBLC.TXT

-----------------------------------
NC-Drill Setup:
-----------------------------------
Drill files format:   INCHES 
Format:   2:5
Leading/trailing zeroes:   Suppress trailing zeroes
Coordinate positions:   Reference to relative origin

other:
+Optimize change location commands
